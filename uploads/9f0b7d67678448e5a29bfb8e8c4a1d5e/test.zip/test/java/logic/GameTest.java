
package test.java.logic;

class GameTest {
    GameTest() { /* compiled code */ }

    @org.junit.Test
    public void allGame1() { /* compiled code */ }
}